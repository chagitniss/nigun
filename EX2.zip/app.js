
var myApp = angular.module("myApp", ["ngRoute"]);
myApp.config(function ($routeProvider) {
    $routeProvider

    .when('/', {
        templateUrl: 'home.html',
        controller: 'mainController'
    })
    .when('/project', {
        templateUrl: 'project.html',
        controller: 'Cproject'
    })
    .when('/contact', {
        templateUrl: 'contact.html',
        controller: 'Ccontact'
    });
});
myApp.controller('mainController', function ($scope) {
    $scope.message = 'home sweet home';
});
myApp.controller('Cproject', function ($scope) {
    $scope.message = 'this is my big project';
});
myApp.controller('Ccontact', function ($scope) {
    $scope.message = 'keep in touch';
});

